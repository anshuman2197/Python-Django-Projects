from django.db import models

# Create your models here.
DIFF_CHOICES=(
    ('returnable','RETURNABLE'),
    ('non-returnable','NON-RETURNABLE'),
    ('personale-belonging','PERSONAL-BELONGING'),
    ('dead','DEAD'),
    ('not-working','NOT-WORKING'),
    ('some are working','SOME ARE WORKING'),
    ('other','OTHER'),
)
class User(models.Model):
    company=models.CharField(max_length=150)
    date=models.DateField()
    vehicle_no=models.IntegerField()
    time=models.TimeField()
    contact_person=models.CharField(max_length=150)
    item=models.CharField(max_length=150)
    quantity=models.IntegerField()
    uom=models.IntegerField()
    remark=models.CharField(max_length=50)
    # total_quantity=models.IntegerField()
    checked_by=models.CharField(max_length=50)
    status=models.CharField(max_length=20,choices=DIFF_CHOICES,default='None')
