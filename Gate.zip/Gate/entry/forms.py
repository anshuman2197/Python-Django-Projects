from django.core import validators
from django import forms 
from .models import User
from django.contrib.admin.widgets import AdminTimeWidget

class GateRegistration(forms.ModelForm):
    class Meta:
        model=User
        fields=[
        'company',
        'date',
        'vehicle_no',
        'time',
        'contact_person',
        'item',
        'quantity',
        'uom',
        'remark',
        # 'total_qty'
        'checked_by',
        'status'
        ]
        widgets={
            'company':forms.TextInput(attrs={'class':'form-control'}),
            'date':forms.DateInput( attrs={'type': 'date','class':'form-control'}),
            'vehicle_no':forms.TextInput(attrs={'class':'form-control'}),
            'time':forms.TimeInput(attrs={'type': 'time','class':'form-control'}),
            'contact_person':forms.TextInput(attrs={'class':'form-control'}),
            'item':forms.TextInput(attrs={'class':'form-control'}),
            'quantity':forms.NumberInput(attrs={'class':'form-control'}),
            'uom':forms.NumberInput(attrs={'class':'form-control'}),
            'remark':forms.TextInput(attrs={'class':'form-control'}),
        # 'total_qty'
            'checked_by':forms.TextInput(attrs={'class':'form-control'}),
            # 'status':forms.TextInput(attrs={'type':'d-flex','class':'dropdown-toggle'}),

        }