from django.shortcuts import render
from .forms import GateRegistration
from .models import User
from django.http import HttpResponseRedirect
# Create your views here.
def add(request):
    if request.method=='POST':
        fm=GateRegistration(request.POST)
        if fm.is_valid():
            cm=fm.cleaned_data['company']
            dt=fm.cleaned_data['date']
            vn=fm.cleaned_data['vehicle_no']
            tm=fm.cleaned_data[ 'time']
            cp=fm.cleaned_data['contact_person']
            it=fm.cleaned_data['item']
            qn=fm.cleaned_data['quantity']
            um=fm.cleaned_data['uom']
            re=fm.cleaned_data['remark']
            cb=fm.cleaned_data['checked_by']
            st=fm.cleaned_data[ 'status']
            reg=User(company=cm,date=dt,vehicle_no=vn,time=tm,contact_person=cp,item=it,
            quantity=qn,uom=um,remark=re,checked_by=cb,status=st)
            reg.save()
            fm=GateRegistration()
    else:
        fm=GateRegistration()
    stud=User.objects.all()
    return render(request,"entry/index.html",{'form':fm,'stu':stud})

def delete_data(request,id=None):
    if request.method=="POST":
        pi=User.objects.get(id=id)
        pi.delete()
        return HttpResponseRedirect('/')

def update_data(request,id=None):
    if request.method=='POST':
        pi=User.objects.get(id=id)
        fm=GateRegistration(request.POST,instance=pi)
        if fm.is_valid():
            fm.save()
    else:
        pi=User.objects.get(id=id)
        fm=GateRegistration(instance=pi)
    return render(request,'entry/update.html',{'form':fm})
